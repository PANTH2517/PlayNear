package com.example.playnear;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    DBHelper dbHelper ;

    TextView tv1 ;

    SharedPreferences sp ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        dbHelper = new DBHelper(getApplicationContext());
        sp = getSharedPreferences("playnear_prefs", MODE_PRIVATE);
        tv1 = findViewById(R.id.tv1);

        int userId = sp.getInt("user_id", -1);
        String name = dbHelper.getUserNameHelper(userId);

        if (name.equals("")) {
            sp.edit().clear().commit();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finish();
        } else {
            tv1.setText("Hi, " + name);
        }
    }

    public void findGames(View view) {
        Intent intent = new Intent(getApplicationContext(), FindGamesActivity.class);
        startActivity(intent);
    }

    public void venues(View view) {
        Intent intent = new Intent(getApplicationContext(), VenuesActivity.class);
        startActivity(intent);
    }

    public void myGames(View view) {
        Intent intent = new Intent(getApplicationContext(), MyGamesActivity.class);
        startActivity(intent);
    }

    public void createGame(View view) {
        Intent intent = new Intent(getApplicationContext(), CreateGameActivity.class);
        startActivity(intent);
    }

    public void logOut(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
        builder.setTitle("Log Out");
        builder.setMessage("Do you want to log out ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                sp.edit().clear().commit();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("No", null);
        builder.show();
    }
}
