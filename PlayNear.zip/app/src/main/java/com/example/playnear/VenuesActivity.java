package com.example.playnear;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class VenuesActivity extends AppCompatActivity implements LocationListener {

    DBHelper dbHelper ;

    Spinner sp1 ;

    ListView lv1 ;

    TextView tv1 ;

    LocationManager locationManager ;

    Location myLocation = null ;

    ArrayList<Venue> shownVenues = new ArrayList<>();

    String[] sports = {"All sports", "Football", "Cricket", "Badminton", "Basketball", "Tennis", "Volleyball"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_venues);

        dbHelper = new DBHelper(getApplicationContext());
        sp1 = findViewById(R.id.sp1);
        lv1 = findViewById(R.id.lv1);
        tv1 = findViewById(R.id.tv1);

        sp1.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, sports));

        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                showVenues();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final Venue venue = shownVenues.get(position);

                String message = venue.sport + "\n" + venue.address;
                if (venue.distance >= 0) {
                    message = message + "\n" + String.format("%.1f", venue.distance) + " km away";
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(VenuesActivity.this);
                builder.setTitle(venue.name);
                builder.setMessage(message);
                builder.setPositiveButton("Navigate", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Uri uri = Uri.parse("geo:" + venue.latitude + "," + venue.longitude + "?q=" + venue.latitude + "," + venue.longitude + "(" + Uri.encode(venue.name) + ")");
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        intent.setPackage("com.google.android.apps.maps");
                        try {
                            startActivity(intent);
                        } catch (Exception e) {
                            Toast.makeText(VenuesActivity.this, "Google Maps is not installed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                builder.setNegativeButton("Close", null);
                builder.show();
            }
        });

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getMyLocation();
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        showVenues();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getMyLocation();
        } else {
            Toast.makeText(this, "Location permission denied , distance will not be shown", Toast.LENGTH_LONG).show();
            showVenues();
        }
    }

    public void getMyLocation() {
        Location gps = null;
        Location network = null;
        try {
            gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            network = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) {
        }

        if (gps != null) {
            myLocation = gps;
        } else if (network != null) {
            myLocation = network;
        }

        if (myLocation != null) {
            showVenues();
        } else {
            boolean gpsOn = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            boolean networkOn = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            if (gpsOn) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
            }
            if (networkOn) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);
            }
            if (!gpsOn && !networkOn) {
                Toast.makeText(this, "Location is switched off , distance will not be shown", Toast.LENGTH_LONG).show();
                showVenues();
            }
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        myLocation = location;
        locationManager.removeUpdates(this);
        showVenues();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        locationManager.removeUpdates(this);
    }

    public void showVenues() {

        shownVenues = dbHelper.getVenuesHelper(sp1.getSelectedItem().toString());

        for (int i = 0; i < shownVenues.size(); i++) {
            Venue venue = shownVenues.get(i);
            if (myLocation != null) {
                float[] results = new float[1];
                Location.distanceBetween(myLocation.getLatitude(), myLocation.getLongitude(), venue.latitude, venue.longitude, results);
                venue.distance = results[0] / 1000.0;
            } else {
                venue.distance = -1;
            }
        }

        if (myLocation != null) {
            Collections.sort(shownVenues, new Comparator<Venue>() {
                @Override
                public int compare(Venue v1, Venue v2) {
                    return Double.compare(v1.distance, v2.distance);
                }
            });
        }

        ArrayList<String> rows = new ArrayList<>();
        for (int i = 0; i < shownVenues.size(); i++) {
            Venue venue = shownVenues.get(i);
            String row = venue.name + "\n" + venue.sport + "\n" + venue.address;
            if (venue.distance >= 0) {
                row = row + "\n" + String.format("%.1f", venue.distance) + " km away";
            }
            rows.add(row);
        }
        lv1.setAdapter(new ArrayAdapter<String>(this, R.layout.row, rows));

        if (myLocation == null) {
            tv1.setText("Location not known , distance is hidden :");
        } else {
            tv1.setText("Venues ( nearest first ) :");
        }
    }

    public void addVenue(View view) {
        Intent intent = new Intent(getApplicationContext(), AddVenueActivity.class);
        startActivity(intent);
    }

    public void goBack(View view) {
        Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }
}
