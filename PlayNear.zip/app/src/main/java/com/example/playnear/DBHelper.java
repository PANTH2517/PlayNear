package com.example.playnear;

import android.content.Context;
import android.os.StrictMode;
import android.widget.Toast;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Random;

public class DBHelper {

    private static final String BASE_URL = "https://playnear-5e483-default-rtdb.asia-southeast1.firebasedatabase.app";

    Context context ;

    public DBHelper(Context applicationContext) {

        context = applicationContext;

        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());
    }

    private String request(String method, String path, String body) {
        try {
            URL url = new URL(BASE_URL + path);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(method);
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(10000);
            if (body != null) {
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json");
                OutputStream outputStream = connection.getOutputStream();
                outputStream.write(body.getBytes("UTF-8"));
                outputStream.close();
            }
            int code = connection.getResponseCode();
            if (code >= 400) {
                return null;
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            StringBuffer buffer = new StringBuffer();
            String line;
            while ((line = reader.readLine()) != null) {
                buffer.append(line);
            }
            reader.close();
            return buffer.toString();
        } catch (Exception e) {
            Toast.makeText(context, "No internet connection", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    private JSONObject getObject(String path) {
        String text = request("GET", path, null);
        if (text == null) {
            return null;
        }
        try {
            Object value = new JSONTokener(text).nextValue();
            if (value instanceof JSONObject) {
                return (JSONObject) value;
            }
        } catch (Exception e) {
        }
        return null;
    }

    private String getString(String path) {
        String text = request("GET", path, null);
        if (text == null) {
            return null;
        }
        try {
            Object value = new JSONTokener(text).nextValue();
            if (value instanceof String) {
                return (String) value;
            }
        } catch (Exception e) {
        }
        return null;
    }

    private int getNumber(String path) {
        String text = request("GET", path, null);
        if (text == null) {
            return -1;
        }
        try {
            return Integer.parseInt(text.trim());
        } catch (Exception e) {
            return -1;
        }
    }

    private String rawEmailKey(String email) {
        return email.replace(".", ",").replace("#", "_").replace("$", "_").replace("[", "_").replace("]", "_").replace("/", "_");
    }

    private String emailKey(String email) {
        try {
            return URLEncoder.encode(rawEmailKey(email), "UTF-8");
        } catch (Exception e) {
            return rawEmailKey(email);
        }
    }

    private JSONObject userJson(String name, String email, String password) throws Exception {
        JSONObject user = new JSONObject();
        user.put("name", name);
        user.put("email", email);
        user.put("password", hashPassword(password));
        return user;
    }

    private JSONObject venueJson(String name, String sport, String address, double lat, double lng) throws Exception {
        JSONObject venue = new JSONObject();
        venue.put("name", name);
        venue.put("sport", sport);
        venue.put("address", address);
        venue.put("lat", lat);
        venue.put("lng", lng);
        return venue;
    }

    private String hashPassword(String password) {
        String salt = String.valueOf(new Random().nextInt(900000) + 100000);
        return salt + ":" + sha256(salt + password);
    }

    private String sha256(String text) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(text.getBytes("UTF-8"));
            StringBuffer buffer = new StringBuffer();
            for (int i = 0; i < bytes.length; i++) {
                buffer.append(String.format("%02x", bytes[i]));
            }
            return buffer.toString();
        } catch (Exception e) {
            return "";
        }
    }

    public boolean registerUserHelper(String name, String email, String password) {
        String key = emailKey(email);
        String existing = request("GET", "/emails/" + key + ".json", null);
        if (existing == null || !existing.trim().equals("null")) {
            return false;
        }
        int userId = new Random().nextInt(2000000000) + 10;
        try {
            JSONObject user = userJson(name, email, password);
            if (request("PUT", "/users/u" + userId + ".json", user.toString()) == null) {
                return false;
            }
            request("PUT", "/emails/" + key + ".json", String.valueOf(userId));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public int loginUserHelper(String email, String password) {
        int userId = getNumber("/emails/" + emailKey(email) + ".json");
        if (userId == -1) {
            return -1;
        }
        String saved = getString("/users/u" + userId + "/password.json");
        if (saved == null) {
            return -1;
        }
        String[] parts = saved.split(":");
        if (parts.length == 2 && parts[1].equals(sha256(parts[0] + password))) {
            return userId;
        }
        return -1;
    }

    public String getUserNameHelper(int userId) {
        String name = getString("/users/u" + userId + "/name.json");
        if (name == null) {
            return "";
        }
        return name;
    }

    public long addVenueHelper(String name, String sport, String address, double lat, double lng) {
        int venueId = new Random().nextInt(2000000000) + 100;
        try {
            JSONObject venue = venueJson(name, sport, address, lat, lng);
            if (request("PUT", "/venues/v" + venueId + ".json", venue.toString()) == null) {
                return -1;
            }
            return venueId;
        } catch (Exception e) {
            return -1;
        }
    }

    public ArrayList<Venue> getVenuesHelper(String sport) {
        ArrayList<Venue> list = new ArrayList<>();
        JSONObject all = getObject("/venues.json");
        if (all == null) {
            return list;
        }
        Iterator<String> keys = all.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject item = all.optJSONObject(key);
            if (item == null) {
                continue;
            }
            if (!sport.equals("All sports") && !sport.equals(item.optString("sport"))) {
                continue;
            }
            Venue venue = new Venue();
            venue.id = Integer.parseInt(key.substring(1));
            venue.name = item.optString("name");
            venue.sport = item.optString("sport");
            venue.address = item.optString("address");
            venue.latitude = item.optDouble("lat");
            venue.longitude = item.optDouble("lng");
            list.add(venue);
        }
        Collections.sort(list, new Comparator<Venue>() {
            @Override
            public int compare(Venue v1, Venue v2) {
                return v1.name.compareToIgnoreCase(v2.name);
            }
        });
        return list;
    }

    public boolean addGameHelper(int creatorId, int venueId, String sport, String date, String time, int maxPlayers) {
        JSONObject venue = getObject("/venues/v" + venueId + ".json");
        String creatorName = getString("/users/u" + creatorId + "/name.json");
        if (venue == null || creatorName == null) {
            return false;
        }
        try {
            JSONObject players = new JSONObject();
            players.put("u" + creatorId, creatorName);

            JSONObject game = new JSONObject();
            game.put("creatorId", creatorId);
            game.put("creatorName", creatorName);
            game.put("venueId", venueId);
            game.put("venueName", venue.getString("name"));
            game.put("address", venue.getString("address"));
            game.put("lat", venue.getDouble("lat"));
            game.put("lng", venue.getDouble("lng"));
            game.put("sport", sport);
            game.put("date", date);
            game.put("time", time);
            game.put("maxPlayers", maxPlayers);
            game.put("status", "OPEN");
            game.put("players", players);

            int gameId = new Random().nextInt(2000000000) + 100;
            return request("PUT", "/games/g" + gameId + ".json", game.toString()) != null;
        } catch (Exception e) {
            return false;
        }
    }

    public ArrayList<Game> getGamesHelper(int userId) {
        ArrayList<Game> list = new ArrayList<>();
        JSONObject all = getObject("/games.json");
        if (all == null) {
            return list;
        }
        Iterator<String> keys = all.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject item = all.optJSONObject(key);
            if (item == null) {
                continue;
            }
            JSONObject players = item.optJSONObject("players");
            if (userId != 0 && (players == null || !players.has("u" + userId))) {
                continue;
            }
            Game game = new Game();
            game.id = Integer.parseInt(key.substring(1));
            game.creatorId = item.optInt("creatorId");
            game.creatorName = item.optString("creatorName");
            game.sport = item.optString("sport");
            game.venueName = item.optString("venueName");
            game.address = item.optString("address");
            game.latitude = item.optDouble("lat");
            game.longitude = item.optDouble("lng");
            game.date = item.optString("date");
            game.time = item.optString("time");
            game.maxPlayers = item.optInt("maxPlayers");
            game.players = 0;
            if (players != null) {
                game.players = players.length();
            }
            game.status = item.optString("status");
            if (hasStarted(game.date, game.time)) {
                game.status = "COMPLETED";
            }
            list.add(game);
        }
        Collections.sort(list, new Comparator<Game>() {
            @Override
            public int compare(Game g1, Game g2) {
                return (g1.date + g1.time).compareTo(g2.date + g2.time);
            }
        });
        return list;
    }

    public String getPlayersHelper(int gameId) {
        JSONObject players = getObject("/games/g" + gameId + "/players.json");
        StringBuffer buffer = new StringBuffer();
        if (players != null) {
            Iterator<String> keys = players.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                buffer.append(players.optString(key) + "\n");
            }
        }
        return buffer.toString();
    }

    public int joinGameHelper(int gameId, int userId) {
        JSONObject game = getObject("/games/g" + gameId + ".json");
        if (game == null) {
            return 6;
        }
        JSONObject players = game.optJSONObject("players");
        int count = 0;
        if (players != null) {
            count = players.length();
            if (players.has("u" + userId)) {
                return 1;
            }
        }
        if (hasStarted(game.optString("date"), game.optString("time"))) {
            return 3;
        }
        int max = game.optInt("maxPlayers");
        if (count >= max) {
            return 2;
        }

        String name = getString("/users/u" + userId + "/name.json");
        if (name == null) {
            name = "Player";
        }
        request("PUT", "/games/g" + gameId + "/players/u" + userId + ".json", JSONObject.quote(name));

        if (count + 1 >= max) {
            request("PUT", "/games/g" + gameId + "/status.json", "\"FULL\"");
        }
        return 0;
    }

    public int leaveGameHelper(int gameId, int userId) {
        JSONObject game = getObject("/games/g" + gameId + ".json");
        if (game == null) {
            return 6;
        }
        if (game.optInt("creatorId") == userId) {
            return 4;
        }
        if (hasStarted(game.optString("date"), game.optString("time"))) {
            return 3;
        }
        JSONObject players = game.optJSONObject("players");
        if (players == null || !players.has("u" + userId)) {
            return 5;
        }

        request("DELETE", "/games/g" + gameId + "/players/u" + userId + ".json", null);
        request("PUT", "/games/g" + gameId + "/status.json", "\"OPEN\"");
        return 0;
    }

    public static boolean hasStarted(String date, String time) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
            Date gameTime = format.parse(date + " " + time);
            return gameTime.getTime() <= System.currentTimeMillis();
        } catch (Exception e) {
            return false;
        }
    }
}
