package com.example.playnear;

public class Venue {

    int id ;
    String name ;
    String sport ;
    String address ;
    double latitude ;
    double longitude ;
    double distance = -1 ;

}
