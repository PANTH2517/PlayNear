package com.example.playnear;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;

public class CreateGameActivity extends AppCompatActivity {

    DBHelper dbHelper ;

    Spinner sp1 , sp2 ;

    Button bt1 , bt2 , bt3 , bt4 ;

    EditText et1 , et2 , et3 ;

    ArrayList<Venue> venues = new ArrayList<>();

    String selectedDate = "" ;
    String selectedTime = "" ;

    int userId ;

    int newVenueId = -1 ;

    String[] sports = {"Football", "Cricket", "Badminton", "Basketball", "Tennis", "Volleyball"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_game);

        dbHelper = new DBHelper(getApplicationContext());
        sp1 = findViewById(R.id.sp1);
        sp2 = findViewById(R.id.sp2);
        bt1 = findViewById(R.id.bt1);
        bt2 = findViewById(R.id.bt2);
        bt3 = findViewById(R.id.bt3);
        bt4 = findViewById(R.id.bt4);
        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        et3 = findViewById(R.id.et3);

        SharedPreferences sp = getSharedPreferences("playnear_prefs", MODE_PRIVATE);
        userId = sp.getInt("user_id", -1);

        sp1.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, sports));

        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadVenues();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddVenueActivity.class);
                startActivityForResult(intent, 1);
            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                DatePickerDialog dialog = new DatePickerDialog(CreateGameActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        selectedDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth);
                        et2.setText(selectedDate);
                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                dialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                dialog.show();
            }
        });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog dialog = new TimePickerDialog(CreateGameActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        selectedTime = String.format("%02d:%02d", hourOfDay, minute);
                        et3.setText(selectedTime);
                    }
                }, 18, 0, true);
                dialog.show();
            }
        });

        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int position = sp2.getSelectedItemPosition();
                if (position < 0 || position >= venues.size()) {
                    Toast.makeText(CreateGameActivity.this, "No venue available , add a venue first", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (selectedDate.equals("")) {
                    Toast.makeText(CreateGameActivity.this, "Choose a date", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (selectedTime.equals("")) {
                    Toast.makeText(CreateGameActivity.this, "Choose a start time", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (DBHelper.hasStarted(selectedDate, selectedTime)) {
                    Toast.makeText(CreateGameActivity.this, "The start time must be in the future", Toast.LENGTH_SHORT).show();
                    return;
                }

                String max = et1.getText().toString().trim();
                if (max.equals("")) {
                    Toast.makeText(CreateGameActivity.this, "Enter the maximum players", Toast.LENGTH_SHORT).show();
                    return;
                }
                int maxPlayers = Integer.parseInt(max);
                if (maxPlayers < 2 || maxPlayers > 30) {
                    Toast.makeText(CreateGameActivity.this, "Maximum players must be from 2 to 30", Toast.LENGTH_SHORT).show();
                    return;
                }

                Venue venue = venues.get(position);
                if (dbHelper.addGameHelper(userId, venue.id, venue.sport, selectedDate, selectedTime, maxPlayers)) {
                    Toast.makeText(CreateGameActivity.this, "Game Created", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(CreateGameActivity.this, "Error", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void loadVenues() {
        venues = dbHelper.getVenuesHelper(sp1.getSelectedItem().toString());
        ArrayList<String> names = new ArrayList<>();
        int select = 0;
        for (int i = 0; i < venues.size(); i++) {
            names.add(venues.get(i).name);
            if (venues.get(i).id == newVenueId) {
                select = i;
            }
        }
        if (venues.size() == 0) {
            names.add("No venue available");
        }
        sp2.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, names));
        sp2.setSelection(select);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadVenues();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            newVenueId = data.getIntExtra("key_venue_id", -1);
            String sport = data.getStringExtra("key_sport");
            int position = 0;
            for (int i = 0; i < sports.length; i++) {
                if (sports[i].equals(sport)) {
                    position = i;
                }
            }
            if (sp1.getSelectedItemPosition() == position) {
                loadVenues();
            } else {
                sp1.setSelection(position);
            }
        }
    }

    public void goBack(View view) {
        Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }
}
