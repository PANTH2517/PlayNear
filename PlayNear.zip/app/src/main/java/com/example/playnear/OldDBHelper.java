// OldDBHelper.java
//
// This is the ORIGINAL DBHelper of PlayNear, written by us in the classic way taught in our
// lab experiments : SQLiteOpenHelper , onCreate with CREATE TABLE , onUpgrade , ContentValues ,
// Cursor , insert / query / update / delete. All data was stored in the SQLite database on the phone.
//
// Later , on the advice of our professor , the database was moved online so that every phone
// sees the same data. For that online integration ( Firebase Realtime Database over HTTP ,
// HttpURLConnection and JSON ) we took help of AI. The new code is in DBHelper.java ,
// with the same method names , so the activities did not change.
//
// This whole file is commented , so it is NOT part of the running app.
// It is kept only to show our original SQLite work.
// The same code is also saved in git as the tag sqlite-version.
//
// ----------------------------------------------------------------------

// package com.example.playnear;
//
// import android.content.ContentValues;
// import android.content.Context;
// import android.database.Cursor;
// import android.database.sqlite.SQLiteDatabase;
// import android.database.sqlite.SQLiteOpenHelper;
//
// import java.security.MessageDigest;
// import java.text.SimpleDateFormat;
// import java.util.ArrayList;
// import java.util.Calendar;
// import java.util.Date;
// import java.util.Locale;
// import java.util.Random;
//
// public class DBHelper extends SQLiteOpenHelper {
//
//     private static final String DATABASE_NAME = "playnear_db";
//     private static final int DATABASE_VER = 1;
//
//     public DBHelper(Context applicationContext) {
//
//         super(applicationContext, DATABASE_NAME, null, DATABASE_VER);
//     }
//
//     @Override
//     public void onConfigure(SQLiteDatabase db) {
//         super.onConfigure(db);
//         db.setForeignKeyConstraintsEnabled(true);
//     }
//
//     @Override
//     public void onCreate(SQLiteDatabase db) {
//
//         String create_users = "CREATE TABLE users(userID INTEGER PRIMARY KEY AUTOINCREMENT , userNAME TEXT , userEMAIL TEXT UNIQUE , userPASSWORD TEXT )";
//         String create_venues = "CREATE TABLE venues(venueID INTEGER PRIMARY KEY AUTOINCREMENT , venueNAME TEXT , venueSPORT TEXT , venueADDRESS TEXT , venueLAT REAL , venueLNG REAL )";
//         String create_games = "CREATE TABLE games(gameID INTEGER PRIMARY KEY AUTOINCREMENT , creatorID INTEGER , venueID INTEGER , gameSPORT TEXT , gameDATE TEXT , gameTIME TEXT , maxPLAYERS INTEGER , gameSTATUS TEXT )";
//         String create_players = "CREATE TABLE game_players(gameID INTEGER , userID INTEGER , PRIMARY KEY (gameID , userID) , FOREIGN KEY (gameID) REFERENCES games(gameID) ON DELETE CASCADE , FOREIGN KEY (userID) REFERENCES users(userID) ON DELETE CASCADE )";
//
//         db.execSQL(create_users);
//         db.execSQL(create_venues);
//         db.execSQL(create_games);
//         db.execSQL(create_players);
//
//         long u1 = insertUser(db, "Demo Player One", "demo1@playnear.com", "demo123");
//         long u2 = insertUser(db, "Demo Player Two", "demo2@playnear.com", "demo123");
//
//         long v1 = insertVenue(db, "NMIMS Shirpur Football Ground", "Football", "NMIMS Campus, Mumbai-Agra Highway, Shirpur", 21.3000, 74.8900);
//         long v2 = insertVenue(db, "Shirpur Cricket Ground", "Cricket", "Near Bus Stand, Shirpur", 21.3510, 74.8800);
//         long v3 = insertVenue(db, "NMIMS Indoor Badminton Hall", "Badminton", "NMIMS Campus, Shirpur", 21.3005, 74.8895);
//         long v4 = insertVenue(db, "Shirpur Sports Club Courts", "Basketball", "Station Road, Shirpur", 21.3480, 74.8750);
//         long v5 = insertVenue(db, "Tapi Tennis Academy", "Tennis", "Tapi Road, Shirpur", 21.3560, 74.8860);
//         long v6 = insertVenue(db, "Shirpur Volleyball Ground", "Volleyball", "Near Kharde Road, Shirpur", 21.3440, 74.8920);
//         long v7 = insertVenue(db, "Dhule District Stadium", "Football", "Stadium Road, Dhule", 20.9040, 74.7750);
//         long v8 = insertVenue(db, "Dhule Cricket Maidan", "Cricket", "Deopur, Dhule", 20.9100, 74.7850);
//         long v9 = insertVenue(db, "Dhule Indoor Sports Hall", "Badminton", "Sakri Road, Dhule", 20.8980, 74.7700);
//         long v10 = insertVenue(db, "Dhule Basketball Court", "Basketball", "Agra Road, Dhule", 20.9070, 74.7790);
//         long v11 = insertVenue(db, "Dhule Lawn Tennis Club", "Tennis", "Jail Road, Dhule", 20.9010, 74.7770);
//         long v12 = insertVenue(db, "Dhule Beach Volleyball Arena", "Volleyball", "Panzara River Side, Dhule", 20.9120, 74.7690);
//
//         insertGame(db, v1, "Football", u1, 0, "18:00", 10, 0);
//         insertGame(db, v2, "Cricket", u2, 1, "16:00", 22, 0);
//         insertGame(db, v3, "Badminton", u2, 0, "19:00", 4, u1);
//         insertGame(db, v4, "Basketball", u1, 2, "17:30", 8, 0);
//         insertGame(db, v5, "Tennis", u1, 1, "07:00", 4, 0);
//         insertGame(db, v6, "Volleyball", u2, 3, "18:00", 12, 0);
//         insertGame(db, v7, "Football", u2, 2, "20:00", 14, u1);
//         insertGame(db, v9, "Badminton", u1, 4, "06:30", 6, 0);
//         insertGame(db, v10, "Basketball", u2, 5, "17:00", 2, u1);
//         insertGame(db, v8, "Cricket", u1, 6, "15:00", 16, 0);
//     }
//
//     @Override
//     public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//
//         db.execSQL("DROP TABLE IF EXISTS game_players");
//         db.execSQL("DROP TABLE IF EXISTS games");
//         db.execSQL("DROP TABLE IF EXISTS venues");
//         db.execSQL("DROP TABLE IF EXISTS users");
//         onCreate(db);
//
//     }
//
//
//     private long insertUser(SQLiteDatabase db, String name, String email, String password) {
//         ContentValues contentValues = new ContentValues();
//         contentValues.put("userNAME", name);
//         contentValues.put("userEMAIL", email);
//         contentValues.put("userPASSWORD", hashPassword(password));
//         return db.insert("users", null, contentValues);
//     }
//
//     private long insertVenue(SQLiteDatabase db, String name, String sport, String address, double lat, double lng) {
//         ContentValues contentValues = new ContentValues();
//         contentValues.put("venueNAME", name);
//         contentValues.put("venueSPORT", sport);
//         contentValues.put("venueADDRESS", address);
//         contentValues.put("venueLAT", lat);
//         contentValues.put("venueLNG", lng);
//         return db.insert("venues", null, contentValues);
//     }
//
//     private void insertGame(SQLiteDatabase db, long venueId, String sport, long creatorId, int days, String time, int max, long extraPlayer) {
//
//         Calendar calendar = Calendar.getInstance();
//         calendar.add(Calendar.DAY_OF_MONTH, days);
//         String date = String.format(Locale.US, "%04d-%02d-%02d", calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH));
//
//         String status = "OPEN";
//         if (extraPlayer > 0 && max <= 2) {
//             status = "FULL";
//         }
//
//         ContentValues contentValues = new ContentValues();
//         contentValues.put("creatorID", creatorId);
//         contentValues.put("venueID", venueId);
//         contentValues.put("gameSPORT", sport);
//         contentValues.put("gameDATE", date);
//         contentValues.put("gameTIME", time);
//         contentValues.put("maxPLAYERS", max);
//         contentValues.put("gameSTATUS", status);
//         long gameId = db.insert("games", null, contentValues);
//
//         ContentValues player1 = new ContentValues();
//         player1.put("gameID", gameId);
//         player1.put("userID", creatorId);
//         db.insert("game_players", null, player1);
//
//         if (extraPlayer > 0) {
//             ContentValues player2 = new ContentValues();
//             player2.put("gameID", gameId);
//             player2.put("userID", extraPlayer);
//             db.insert("game_players", null, player2);
//         }
//     }
//
//
//     private String hashPassword(String password) {
//         String salt = String.valueOf(new Random().nextInt(900000) + 100000);
//         return salt + ":" + sha256(salt + password);
//     }
//
//     private String sha256(String text) {
//         try {
//             MessageDigest digest = MessageDigest.getInstance("SHA-256");
//             byte[] bytes = digest.digest(text.getBytes("UTF-8"));
//             StringBuffer buffer = new StringBuffer();
//             for (int i = 0; i < bytes.length; i++) {
//                 buffer.append(String.format("%02x", bytes[i]));
//             }
//             return buffer.toString();
//         } catch (Exception e) {
//             return "";
//         }
//     }
//
//
//     public boolean registerUserHelper(String name, String email, String password) {
//         SQLiteDatabase db = this.getWritableDatabase();
//         ContentValues contentValues = new ContentValues();
//         contentValues.put("userNAME", name);
//         contentValues.put("userEMAIL", email);
//         contentValues.put("userPASSWORD", hashPassword(password));
//         long l = db.insert("users", null, contentValues);
//         if (l > 0) {
//             return true;
//         } else {
//             return false;
//         }
//     }
//
//     public int loginUserHelper(String email, String password) {
//         SQLiteDatabase db = this.getReadableDatabase();
//         String[] whereArgs = {email};
//         Cursor cursor = db.rawQuery("SELECT userID , userPASSWORD FROM users WHERE userEMAIL = ?", whereArgs);
//         int userId = -1;
//         if (cursor.moveToFirst()) {
//             String saved = cursor.getString(1);
//             String[] parts = saved.split(":");
//             if (parts.length == 2 && parts[1].equals(sha256(parts[0] + password))) {
//                 userId = cursor.getInt(0);
//             }
//         }
//         cursor.close();
//         return userId;
//     }
//
//     public String getUserNameHelper(int userId) {
//         SQLiteDatabase db = this.getReadableDatabase();
//         String[] whereArgs = {String.valueOf(userId)};
//         Cursor cursor = db.rawQuery("SELECT userNAME FROM users WHERE userID = ?", whereArgs);
//         String name = "";
//         if (cursor.moveToFirst()) {
//             name = cursor.getString(0);
//         }
//         cursor.close();
//         return name;
//     }
//
//
//     public long addVenueHelper(String name, String sport, String address, double lat, double lng) {
//         SQLiteDatabase db = this.getWritableDatabase();
//         return insertVenue(db, name, sport, address, lat, lng);
//     }
//
//     public ArrayList<Venue> getVenuesHelper(String sport) {
//         SQLiteDatabase db = this.getReadableDatabase();
//         Cursor cursor;
//         if (sport.equals("All sports")) {
//             cursor = db.rawQuery("SELECT venueID , venueNAME , venueSPORT , venueADDRESS , venueLAT , venueLNG FROM venues ORDER BY venueNAME", null);
//         } else {
//             String[] whereArgs = {sport};
//             cursor = db.rawQuery("SELECT venueID , venueNAME , venueSPORT , venueADDRESS , venueLAT , venueLNG FROM venues WHERE venueSPORT = ? ORDER BY venueNAME", whereArgs);
//         }
//         ArrayList<Venue> list = new ArrayList<>();
//         while (cursor.moveToNext()) {
//             Venue venue = new Venue();
//             venue.id = cursor.getInt(0);
//             venue.name = cursor.getString(1);
//             venue.sport = cursor.getString(2);
//             venue.address = cursor.getString(3);
//             venue.latitude = cursor.getDouble(4);
//             venue.longitude = cursor.getDouble(5);
//             list.add(venue);
//         }
//         cursor.close();
//         return list;
//     }
//
//
//     public boolean addGameHelper(int creatorId, int venueId, String sport, String date, String time, int maxPlayers) {
//         SQLiteDatabase db = this.getWritableDatabase();
//         ContentValues contentValues = new ContentValues();
//         contentValues.put("creatorID", creatorId);
//         contentValues.put("venueID", venueId);
//         contentValues.put("gameSPORT", sport);
//         contentValues.put("gameDATE", date);
//         contentValues.put("gameTIME", time);
//         contentValues.put("maxPLAYERS", maxPlayers);
//         contentValues.put("gameSTATUS", "OPEN");
//         long gameId = db.insert("games", null, contentValues);
//         if (gameId <= 0) {
//             return false;
//         }
//         ContentValues player = new ContentValues();
//         player.put("gameID", gameId);
//         player.put("userID", creatorId);
//         db.insert("game_players", null, player);
//         return true;
//     }
//
//     public ArrayList<Game> getGamesHelper(int userId) {
//         SQLiteDatabase db = this.getReadableDatabase();
//         String query = "SELECT g.gameID , g.creatorID , g.gameSPORT , g.gameDATE , g.gameTIME , g.maxPLAYERS , g.gameSTATUS , "
//                 + "v.venueNAME , v.venueADDRESS , v.venueLAT , v.venueLNG , "
//                 + "(SELECT COUNT(*) FROM game_players p WHERE p.gameID = g.gameID) , u.userNAME "
//                 + "FROM games g INNER JOIN venues v ON g.venueID = v.venueID INNER JOIN users u ON g.creatorID = u.userID ";
//         Cursor cursor;
//         if (userId == 0) {
//             cursor = db.rawQuery(query + "ORDER BY g.gameDATE , g.gameTIME", null);
//         } else {
//             String[] whereArgs = {String.valueOf(userId)};
//             cursor = db.rawQuery(query + "WHERE g.gameID IN (SELECT gameID FROM game_players WHERE userID = ?) ORDER BY g.gameDATE , g.gameTIME", whereArgs);
//         }
//         ArrayList<Game> list = new ArrayList<>();
//         while (cursor.moveToNext()) {
//             Game game = new Game();
//             game.id = cursor.getInt(0);
//             game.creatorId = cursor.getInt(1);
//             game.sport = cursor.getString(2);
//             game.date = cursor.getString(3);
//             game.time = cursor.getString(4);
//             game.maxPlayers = cursor.getInt(5);
//             game.status = cursor.getString(6);
//             game.venueName = cursor.getString(7);
//             game.address = cursor.getString(8);
//             game.latitude = cursor.getDouble(9);
//             game.longitude = cursor.getDouble(10);
//             game.players = cursor.getInt(11);
//             game.creatorName = cursor.getString(12);
//             if (hasStarted(game.date, game.time)) {
//                 game.status = "COMPLETED";
//             }
//             list.add(game);
//         }
//         cursor.close();
//         return list;
//     }
//
//     public String getPlayersHelper(int gameId) {
//         SQLiteDatabase db = this.getReadableDatabase();
//         String[] whereArgs = {String.valueOf(gameId)};
//         Cursor cursor = db.rawQuery("SELECT u.userNAME FROM users u INNER JOIN game_players p ON u.userID = p.userID WHERE p.gameID = ?", whereArgs);
//         StringBuffer buffer = new StringBuffer();
//         while (cursor.moveToNext()) {
//             buffer.append(cursor.getString(0) + "\n");
//         }
//         cursor.close();
//         return buffer.toString();
//     }
//
//     public int joinGameHelper(int gameId, int userId) {
//         SQLiteDatabase db = this.getWritableDatabase();
//         String[] whereArgs = {String.valueOf(gameId)};
//         Cursor cursor = db.rawQuery("SELECT gameDATE , gameTIME , maxPLAYERS FROM games WHERE gameID = ?", whereArgs);
//         if (!cursor.moveToFirst()) {
//             cursor.close();
//             return 6;
//         }
//         String date = cursor.getString(0);
//         String time = cursor.getString(1);
//         int max = cursor.getInt(2);
//         cursor.close();
//
//         String[] checkArgs = {String.valueOf(gameId), String.valueOf(userId)};
//         Cursor cursor1 = db.rawQuery("SELECT COUNT(*) FROM game_players WHERE gameID = ? AND userID = ?", checkArgs);
//         cursor1.moveToFirst();
//         int already = cursor1.getInt(0);
//         cursor1.close();
//         if (already > 0) {
//             return 1;
//         }
//         if (hasStarted(date, time)) {
//             return 3;
//         }
//
//         Cursor cursor2 = db.rawQuery("SELECT COUNT(*) FROM game_players WHERE gameID = ?", whereArgs);
//         cursor2.moveToFirst();
//         int players = cursor2.getInt(0);
//         cursor2.close();
//         if (players >= max) {
//             return 2;
//         }
//
//         ContentValues contentValues = new ContentValues();
//         contentValues.put("gameID", gameId);
//         contentValues.put("userID", userId);
//         db.insert("game_players", null, contentValues);
//
//         if (players + 1 >= max) {
//             ContentValues status = new ContentValues();
//             status.put("gameSTATUS", "FULL");
//             db.update("games", status, "gameID=?", whereArgs);
//         }
//         return 0;
//     }
//
//     public int leaveGameHelper(int gameId, int userId) {
//         SQLiteDatabase db = this.getWritableDatabase();
//         String[] whereArgs = {String.valueOf(gameId)};
//         Cursor cursor = db.rawQuery("SELECT gameDATE , gameTIME , creatorID FROM games WHERE gameID = ?", whereArgs);
//         if (!cursor.moveToFirst()) {
//             cursor.close();
//             return 6;
//         }
//         String date = cursor.getString(0);
//         String time = cursor.getString(1);
//         int creator = cursor.getInt(2);
//         cursor.close();
//
//         if (creator == userId) {
//             return 4;
//         }
//         if (hasStarted(date, time)) {
//             return 3;
//         }
//
//         String[] deleteArgs = {String.valueOf(gameId), String.valueOf(userId)};
//         int deleted = db.delete("game_players", "gameID=? AND userID=?", deleteArgs);
//         if (deleted == 0) {
//             return 5;
//         }
//
//         ContentValues status = new ContentValues();
//         status.put("gameSTATUS", "OPEN");
//         db.update("games", status, "gameID=?", whereArgs);
//         return 0;
//     }
//
//     public static boolean hasStarted(String date, String time) {
//         try {
//             SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
//             Date gameTime = format.parse(date + " " + time);
//             return gameTime.getTime() <= System.currentTimeMillis();
//         } catch (Exception e) {
//             return false;
//         }
//     }
// }
//
