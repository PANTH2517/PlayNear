package com.example.playnear;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddVenueActivity extends AppCompatActivity {

    DBHelper dbHelper ;

    EditText et1 , et2 ;

    Spinner sp1 ;

    WebView wv1 ;

    TextView tv1 ;

    Button bt1 , bt2 ;

    LocationManager locationManager ;

    Location myLocation = null ;

    double chosenLat = 0 ;
    double chosenLng = 0 ;
    boolean chosen = false ;

    String[] sports = {"Football", "Cricket", "Badminton", "Basketball", "Tennis", "Volleyball"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_venue);

        dbHelper = new DBHelper(getApplicationContext());
        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        sp1 = findViewById(R.id.sp1);
        wv1 = findViewById(R.id.wv1);
        tv1 = findViewById(R.id.tv1);
        bt1 = findViewById(R.id.bt1);
        bt2 = findViewById(R.id.bt2);

        sp1.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, sports));

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        wv1.getSettings().setJavaScriptEnabled(true);
        wv1.addJavascriptInterface(new MapClick(), "Android");
        showMap(21.35, 74.88);

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getMyLocation();
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myLocation == null) {
                    getMyLocation();
                }
                if (myLocation != null) {
                    chosenLat = myLocation.getLatitude();
                    chosenLng = myLocation.getLongitude();
                    chosen = true;
                    tv1.setText("Chosen location : " + String.format("%.5f", chosenLat) + " , " + String.format("%.5f", chosenLng));
                } else {
                    Toast.makeText(AddVenueActivity.this, "Your location is not available", Toast.LENGTH_SHORT).show();
                }
            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = et1.getText().toString().trim();
                String address = et2.getText().toString().trim();

                if (name.length() < 2) {
                    Toast.makeText(AddVenueActivity.this, "Enter the venue name", Toast.LENGTH_SHORT).show();
                } else if (!chosen) {
                    Toast.makeText(AddVenueActivity.this, "Tap on the map to choose the venue location", Toast.LENGTH_SHORT).show();
                } else {
                    if (address.equals("")) {
                        address = String.format("%.5f", chosenLat) + " , " + String.format("%.5f", chosenLng);
                    }
                    String sport = sp1.getSelectedItem().toString();
                    long venueId = dbHelper.addVenueHelper(name, sport, address, chosenLat, chosenLng);
                    if (venueId > 0) {
                        Toast.makeText(AddVenueActivity.this, "Venue Added", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent();
                        intent.putExtra("key_venue_id", (int) venueId);
                        intent.putExtra("key_sport", sport);
                        setResult(RESULT_OK, intent);
                        finish();
                    } else {
                        Toast.makeText(AddVenueActivity.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    public void showMap(double lat, double lng) {
        String web = "<html><head>"
                + "<meta name='viewport' content='width=device-width, initial-scale=1.0'>"
                + "<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'/>"
                + "<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>"
                + "<style>html,body,#map{height:100%;margin:0}</style></head><body>"
                + "<div id='map'></div><script>"
                + "var map = L.map('map').setView([" + lat + "," + lng + "], 15);"
                + "L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);"
                + "var marker = null;"
                + "map.on('click', function(e) {"
                + "if (marker) { marker.setLatLng(e.latlng); } else { marker = L.marker(e.latlng).addTo(map); }"
                + "Android.pickLocation(e.latlng.lat, e.latlng.lng);"
                + "});"
                + "</script></body></html>";
        wv1.loadDataWithBaseURL("https://playnear.example/", web, "text/html", "UTF-8", null);
    }

    public class MapClick {
        @JavascriptInterface
        public void pickLocation(final double lat, final double lng) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    chosenLat = lat;
                    chosenLng = lng;
                    chosen = true;
                    tv1.setText("Chosen location : " + String.format("%.5f", lat) + " , " + String.format("%.5f", lng));
                }
            });
        }
    }

    public void getMyLocation() {
        Location gps = null;
        Location network = null;
        try {
            gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            network = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) {
        }
        if (gps != null) {
            myLocation = gps;
        } else if (network != null) {
            myLocation = network;
        }
        if (myLocation != null && !chosen) {
            showMap(myLocation.getLatitude(), myLocation.getLongitude());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getMyLocation();
        } else {
            Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    public void goBack(View view) {
        finish();
    }
}
