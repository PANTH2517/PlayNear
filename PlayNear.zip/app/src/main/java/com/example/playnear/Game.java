package com.example.playnear;

public class Game {

    int id ;
    int creatorId ;
    String creatorName ;
    String sport ;
    String venueName ;
    String address ;
    double latitude ;
    double longitude ;
    String date ;
    String time ;
    int maxPlayers ;
    int players ;
    String status ;
    double distance = -1 ;

}
