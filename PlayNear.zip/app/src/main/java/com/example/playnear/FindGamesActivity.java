package com.example.playnear;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class FindGamesActivity extends AppCompatActivity implements LocationListener {

    DBHelper dbHelper ;

    Spinner sp1 , sp2 ;

    ListView lv1 ;

    TextView tv1 ;

    LocationManager locationManager ;

    Location myLocation = null ;

    ArrayList<Game> shownGames = new ArrayList<>();

    int userId ;

    String[] sports = {"All sports", "Football", "Cricket", "Badminton", "Basketball", "Tennis", "Volleyball"};

    String[] distances = {"Any distance", "Within 2 km", "Within 5 km", "Within 10 km"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_games);

        dbHelper = new DBHelper(getApplicationContext());
        sp1 = findViewById(R.id.sp1);
        sp2 = findViewById(R.id.sp2);
        lv1 = findViewById(R.id.lv1);
        tv1 = findViewById(R.id.tv1);

        SharedPreferences sp = getSharedPreferences("playnear_prefs", MODE_PRIVATE);
        userId = sp.getInt("user_id", -1);

        sp1.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, sports));
        sp2.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, distances));

        AdapterView.OnItemSelectedListener filterListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                showGames();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        };
        sp1.setOnItemSelectedListener(filterListener);
        sp2.setOnItemSelectedListener(filterListener);

        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final Game game = shownGames.get(position);

                String message = game.venueName + "\n" + game.address + "\n" + game.date + " , " + game.time
                        + "\n" + game.players + "/" + game.maxPlayers + " players  ( " + game.status + " )"
                        + "\nCreated by : " + game.creatorName;
                if (game.distance >= 0) {
                    message = message + "\n" + String.format("%.1f", game.distance) + " km away";
                }
                message = message + "\n\nPlayers :\n" + dbHelper.getPlayersHelper(game.id);

                AlertDialog.Builder builder = new AlertDialog.Builder(FindGamesActivity.this);
                builder.setTitle(game.sport);
                builder.setMessage(message);
                builder.setPositiveButton("Join Game", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int result = dbHelper.joinGameHelper(game.id, userId);
                        if (result == 0) {
                            Toast.makeText(FindGamesActivity.this, "You joined the game", Toast.LENGTH_SHORT).show();
                        } else if (result == 1) {
                            Toast.makeText(FindGamesActivity.this, "You have already joined this game", Toast.LENGTH_SHORT).show();
                        } else if (result == 2) {
                            Toast.makeText(FindGamesActivity.this, "Sorry , this game is full", Toast.LENGTH_SHORT).show();
                        } else if (result == 3) {
                            Toast.makeText(FindGamesActivity.this, "This game has already started", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(FindGamesActivity.this, "Game not found", Toast.LENGTH_SHORT).show();
                        }
                        showGames();
                    }
                });
                builder.setNeutralButton("Navigate", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Uri uri = Uri.parse("geo:" + game.latitude + "," + game.longitude + "?q=" + game.latitude + "," + game.longitude + "(" + Uri.encode(game.venueName) + ")");
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        intent.setPackage("com.google.android.apps.maps");
                        try {
                            startActivity(intent);
                        } catch (Exception e) {
                            Toast.makeText(FindGamesActivity.this, "Google Maps is not installed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                builder.setNegativeButton("Close", null);
                builder.show();
            }
        });

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getMyLocation();
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        showGames();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getMyLocation();
        } else {
            Toast.makeText(this, "Location permission denied , distance will not be shown", Toast.LENGTH_LONG).show();
            showGames();
        }
    }

    public void getMyLocation() {
        Location gps = null;
        Location network = null;
        try {
            gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            network = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) {
        }

        if (gps != null) {
            myLocation = gps;
        } else if (network != null) {
            myLocation = network;
        }

        if (myLocation != null) {
            showGames();
        } else {
            boolean gpsOn = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            boolean networkOn = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            if (gpsOn) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
            }
            if (networkOn) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);
            }
            if (!gpsOn && !networkOn) {
                Toast.makeText(this, "Location is switched off , distance will not be shown", Toast.LENGTH_LONG).show();
                showGames();
            }
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        myLocation = location;
        locationManager.removeUpdates(this);
        showGames();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        locationManager.removeUpdates(this);
    }

    public void showGames() {

        ArrayList<Game> allGames = dbHelper.getGamesHelper(0);

        String sport = sp1.getSelectedItem().toString();
        int position = sp2.getSelectedItemPosition();
        int maxKm = 0;
        if (position == 1) {
            maxKm = 2;
        } else if (position == 2) {
            maxKm = 5;
        } else if (position == 3) {
            maxKm = 10;
        }

        shownGames = new ArrayList<>();
        for (int i = 0; i < allGames.size(); i++) {
            Game game = allGames.get(i);

            if (game.status.equals("COMPLETED")) {
                continue;
            }
            if (!sport.equals("All sports") && !game.sport.equals(sport)) {
                continue;
            }

            if (myLocation != null) {
                float[] results = new float[1];
                Location.distanceBetween(myLocation.getLatitude(), myLocation.getLongitude(), game.latitude, game.longitude, results);
                game.distance = results[0] / 1000.0;
            } else {
                game.distance = -1;
            }

            if (maxKm > 0 && game.distance >= 0 && game.distance > maxKm) {
                continue;
            }
            shownGames.add(game);
        }

        Collections.sort(shownGames, new Comparator<Game>() {
            @Override
            public int compare(Game g1, Game g2) {
                if (g1.distance >= 0 && g2.distance >= 0) {
                    return Double.compare(g1.distance, g2.distance);
                } else if (g1.distance >= 0) {
                    return -1;
                } else if (g2.distance >= 0) {
                    return 1;
                } else {
                    return (g1.date + g1.time).compareTo(g2.date + g2.time);
                }
            }
        });

        ArrayList<String> rows = new ArrayList<>();
        for (int i = 0; i < shownGames.size(); i++) {
            Game game = shownGames.get(i);
            String row = game.sport + "\n" + game.venueName + "\n" + game.date + " , " + game.time
                    + "\n" + game.players + "/" + game.maxPlayers + " players  -  " + game.status
                    + "\nCreated by : " + game.creatorName;
            if (game.distance >= 0) {
                row = row + "\n" + String.format("%.1f", game.distance) + " km away";
            }
            rows.add(row);
        }
        lv1.setAdapter(new ArrayAdapter<String>(this, R.layout.row, rows));

        if (myLocation == null) {
            tv1.setText("Location not known , distance is hidden :");
        } else if (shownGames.size() == 0) {
            tv1.setText("No games found , change the filters or create a game :");
        } else {
            tv1.setText("Games near you ( nearest first ) :");
        }
    }

    public void goBack(View view) {
        Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }
}
