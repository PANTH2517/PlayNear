package com.example.playnear;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MyGamesActivity extends AppCompatActivity {

    DBHelper dbHelper ;

    ListView lv1 ;

    TextView tv1 ;

    ArrayList<Game> myGames = new ArrayList<>();

    int userId ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_games);

        dbHelper = new DBHelper(getApplicationContext());
        lv1 = findViewById(R.id.lv1);
        tv1 = findViewById(R.id.tv1);

        SharedPreferences sp = getSharedPreferences("playnear_prefs", MODE_PRIVATE);
        userId = sp.getInt("user_id", -1);

        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final Game game = myGames.get(position);

                String message = game.venueName + "\n" + game.address + "\n" + game.date + " , " + game.time
                        + "\n" + game.players + "/" + game.maxPlayers + " players  ( " + game.status + " )"
                        + "\nCreated by : " + game.creatorName
                        + "\n\nPlayers :\n" + dbHelper.getPlayersHelper(game.id);

                AlertDialog.Builder builder = new AlertDialog.Builder(MyGamesActivity.this);
                builder.setTitle(game.sport);
                builder.setMessage(message);
                builder.setPositiveButton("Leave Game", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int result = dbHelper.leaveGameHelper(game.id, userId);
                        if (result == 0) {
                            Toast.makeText(MyGamesActivity.this, "You left the game", Toast.LENGTH_SHORT).show();
                        } else if (result == 3) {
                            Toast.makeText(MyGamesActivity.this, "This game has already started", Toast.LENGTH_SHORT).show();
                        } else if (result == 4) {
                            Toast.makeText(MyGamesActivity.this, "You created this game , so you cannot leave it", Toast.LENGTH_SHORT).show();
                        } else if (result == 5) {
                            Toast.makeText(MyGamesActivity.this, "You have not joined this game", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MyGamesActivity.this, "Game not found", Toast.LENGTH_SHORT).show();
                        }
                        showMyGames();
                    }
                });
                builder.setNeutralButton("Navigate", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Uri uri = Uri.parse("geo:" + game.latitude + "," + game.longitude + "?q=" + game.latitude + "," + game.longitude + "(" + Uri.encode(game.venueName) + ")");
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        intent.setPackage("com.google.android.apps.maps");
                        try {
                            startActivity(intent);
                        } catch (Exception e) {
                            Toast.makeText(MyGamesActivity.this, "Google Maps is not installed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                builder.setNegativeButton("Close", null);
                builder.show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        showMyGames();
    }

    public void showMyGames() {

        ArrayList<Game> all = dbHelper.getGamesHelper(userId);

        myGames = new ArrayList<>();
        for (int i = 0; i < all.size(); i++) {
            if (!all.get(i).status.equals("COMPLETED")) {
                myGames.add(all.get(i));
            }
        }

        ArrayList<String> rows = new ArrayList<>();
        for (int i = 0; i < myGames.size(); i++) {
            Game game = myGames.get(i);
            String row = game.sport + "\n" + game.venueName + "\n" + game.date + " , " + game.time
                    + "\n" + game.players + "/" + game.maxPlayers + " players  -  " + game.status
                    + "\nCreated by : " + game.creatorName;
            if (game.creatorId == userId) {
                row = row + "\nYou created this game";
            } else {
                row = row + "\nYou joined this game";
            }
            rows.add(row);
        }
        lv1.setAdapter(new ArrayAdapter<String>(this, R.layout.row, rows));

        if (myGames.size() == 0) {
            tv1.setText("You have no upcoming games created or joined by you.");
        } else {
            tv1.setText("Your upcoming games :");
        }
    }

    public void goBack(View view) {
        Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }
}
